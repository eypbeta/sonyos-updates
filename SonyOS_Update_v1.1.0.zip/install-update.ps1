﻿# ==============================================================================
# SonyOS Pro OTA Güncellemesi (v1.1.0 - KB500101)
# - Masaüstü sağ tık menüsündeki tüm SonyOS araçlarını tek bir "SonyOS Araçları >"
#   alt başlığının içine toplar (Windows 11 "Daha fazla seçenek göster" ile uyumlu).
# - Varsa güncel sonyos_shell.dll ve temaları canlı hot-swap ile yeniler.
# ==============================================================================

$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] SonyOS v1.1.0 (KB500101) guncellemesi uygulaniyor..." -ForegroundColor Cyan

# 1. Eski dağınık sağ tık kayıtlarını kaldır ve tek "SonyOS Araçları >" alt menüsü oluştur
$bgBase = "HKLM:\SOFTWARE\Classes\Directory\Background\shell"
foreach ($oldKey in @("SonyOSThemes", "SonyOSWindowsUpdate", "SonyOSOtaCheck", "SonyOSUpdateHistory", "SonyOSOptimizeRam", "SonyOSDefenderScan")) {
    Remove-Item -Path "$bgBase\$oldKey" -Recurse -Force -ErrorAction SilentlyContinue
}
Remove-Item -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" -Recurse -Force -ErrorAction SilentlyContinue

$menuRoot = "$bgBase\SonyOSMenu"
New-Item -Path "$menuRoot\shell" -Force | Out-Null
Set-ItemProperty -Path $menuRoot -Name "MUIVerb"     -Value "SonyOS Araçları" -Force
Set-ItemProperty -Path $menuRoot -Name "Icon"        -Value "imageres.dll,-106" -Force
Set-ItemProperty -Path $menuRoot -Name "SubCommands" -Value "" -Force

$menuItems = @(
    @{ Key = "01Defender";      Text = "🛡 Sony + Windows Defender Taraması";    Icon = "imageres.dll,-106"; Cmd = "rundll32.exe C:\Windows\System32\sonyos_shell.dll,SonyOSDefenderScan" },
    @{ Key = "02OptimizeRam";   Text = "🧹 Belleği (RAM) Optimize Et";            Icon = "imageres.dll,-15";  Cmd = "rundll32.exe C:\Windows\System32\sonyos_shell.dll,SonyOSOptimizeRam" },
    @{ Key = "03OtaCheck";      Text = "🚀 SonyOS Güncellemesi Denetle (GitHub)"; Icon = "shell32.dll,-47";   Cmd = "rundll32.exe C:\Windows\System32\sonyos_shell.dll,SonyOSUpdateAgent --check" },
    @{ Key = "04UpdateHistory"; Text = "📋 Güncelleme Geçmişi ve Detayları";      Icon = "imageres.dll,-81";  Cmd = "rundll32.exe C:\Windows\System32\sonyos_shell.dll,SonyOSUpdateHistory" },
    @{ Key = "05Themes";        Text = "🎨 Temalar ve Görünüm (Ayarlar)";         Icon = "imageres.dll,-109"; Cmd = "explorer.exe ms-settings:themes" },
    @{ Key = "06WinUpdate";     Text = "🔄 Windows Güncelleştirmeleri";           Icon = "shell32.dll,-47";   Cmd = "explorer.exe ms-settings:windowsupdate" }
)
foreach ($it in $menuItems) {
    $itemPath = "$menuRoot\shell\$($it.Key)"
    New-Item -Path "$itemPath\command" -Force | Out-Null
    Set-ItemProperty -Path $itemPath -Name "MUIVerb" -Value $it.Text -Force
    Set-ItemProperty -Path $itemPath -Name "Icon"    -Value $it.Icon -Force
    Set-ItemProperty -Path "$itemPath\command" -Name "(Default)" -Value $it.Cmd -Force
}

# 2. Varsa paketteki güncel sonyos_shell.dll & temaları canlı olarak uygula
$sysDll = "C:\Windows\System32\sonyos_shell.dll"
$newDll = Join-Path $PSScriptRoot "files\sonyos_shell.dll"
$win12  = "C:\Windows\Win12"

if (Test-Path $newDll) {
    if (Test-Path $sysDll) {
        Start-Process "rundll32.exe" -ArgumentList "$sysDll,SonyOSShellMain --stop" -Wait -WindowStyle Hidden
        Start-Process "rundll32.exe" -ArgumentList "$sysDll,SonyOSDefenderAgent --stop" -Wait -WindowStyle Hidden
        Start-Sleep -Milliseconds 300
        Move-Item -Path $sysDll -Destination "$sysDll.old" -Force
    }
    Copy-Item -Path $newDll -Destination $sysDll -Force
    if (Test-Path $win12) { Copy-Item -Path $newDll -Destination (Join-Path $win12 "sonyos_shell.dll") -Force }
}

$themesSrc = Join-Path $PSScriptRoot "files\themes"
if (Test-Path $themesSrc) {
    Copy-Item -Path "$themesSrc\*.theme" -Destination "C:\Windows\Resources\Themes" -Force
    if (Test-Path $win12) { Copy-Item -Path "$themesSrc\*" -Destination (Join-Path $win12 "themes") -Force }
}

# Not: SYSTEM oturumundan kullanıcı Session 1 GUI başlatmamak için yalnızca yenilenen DLL'e göre
# mevcut çalışan Defender'ı tazele; SonyOSShellMain bir sonraki oturumda yeni DLL ile açılır veya mevcut kabuk korunur.
if (Test-Path $newDll) {
    Start-Process "rundll32.exe" -ArgumentList "$sysDll,SonyOSDefenderAgent" -WindowStyle Hidden
}

Write-Host "[+] SonyOS v1.1.0 (KB500101) guncellemesi tamamlandi!" -ForegroundColor Green
