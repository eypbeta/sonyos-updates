# ==============================================================================
# SonyOS OTA Güncelleme Kurulum Şablonu (v1.1.0)
# Bu klasöre ekleyeceğiniz yeni duvar kağıtları, scriptler veya .msu dosyaları
# hedef SonyOS kurulumlarına otomatik olarak uygulanır.
# ==============================================================================

$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] SonyOS v1.1.0 guncellemesi uygulaniyor..." -ForegroundColor Cyan

# Örnek: Yeni script veya dosya kopyalama
$targetDir = "C:\Windows\Win12"
if (Test-Path $targetDir) {
    # Copy-Item -Path "$PSScriptRoot\files\*" -Destination $targetDir -Recurse -Force
    Write-Host "[+] SonyOS sistem dizini guncellendi: $targetDir" -ForegroundColor Green
}

# Örnek: Kayıt defteri ince ayarı
# Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "MenuShowDelay" -Value "0" -Force

Write-Host "[+] SonyOS v1.1.0 guncellemesi tamamlandi!" -ForegroundColor Green