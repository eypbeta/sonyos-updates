﻿# ==============================================================================
# SonyOS Pro OTA Güncellemesi (v1.1.0 - KB500101)
# - Masaüstü sağ tık menüsündeki tüm ekstra SonyOS öğelerini kaldırarak
#   %100 temiz orijinal Windows 11 sağ tık deneyimini geri getirir.
# - Güncel sonyos_shell.dll ve temaları canlı hot-swap ile yeniler.
# ==============================================================================

$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] SonyOS v1.1.0 (KB500101) guncellemesi uygulaniyor..." -ForegroundColor Cyan

# 1. Masaüstü sağ tık menüsündeki tüm ekstra SonyOS kayıtlarını tamamen temizle
$bgBase = "HKLM:\SOFTWARE\Classes\Directory\Background\shell"
foreach ($oldKey in @("SonyOSMenu", "SonyOSThemes", "SonyOSWindowsUpdate", "SonyOSOtaCheck", "SonyOSUpdateHistory", "SonyOSOptimizeRam", "SonyOSDefenderScan")) {
    Remove-Item -Path "$bgBase\$oldKey" -Recurse -Force -ErrorAction SilentlyContinue
}
Remove-Item -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" -Recurse -Force -ErrorAction SilentlyContinue

# 1b. Microsoft Ayarlar > Windows Update sayfasını gizle & sadece SonyOS Update Merkezini kullan
$expPol = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
New-Item -Path $expPol -Force | Out-Null
Set-ItemProperty -Path $expPol -Name "SettingsPageVisibility" -Value "hide:windowsupdate" -Type String
$wuBase = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
New-Item -Path "$wuBase\AU" -Force | Out-Null
Set-ItemProperty -Path "$wuBase\AU" -Name "NoAutoUpdate" -Value 1 -Type DWord
Set-ItemProperty -Path "$wuBase\AU" -Name "UseWUServer"  -Value 1 -Type DWord
Set-ItemProperty -Path $wuBase      -Name "DisableWindowsUpdateAccess" -Value 1 -Type DWord
Set-ItemProperty -Path $wuBase      -Name "SetDisableUXWUAccess"       -Value 1 -Type DWord
Set-ItemProperty -Path $wuBase      -Name "DoNotConnectToWindowsUpdateInternetLocations" -Value 1 -Type DWord
Set-ItemProperty -Path $wuBase      -Name "WUServer"       -Value "http://127.0.0.1" -Type String
Set-ItemProperty -Path $wuBase      -Name "WUStatusServer" -Value "http://127.0.0.1" -Type String

$startLnk = Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\SonyOS Update.lnk"
try {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($startLnk)
    $sc.TargetPath = "$env:SystemRoot\System32\rundll32.exe"
    $sc.Arguments = "C:\Windows\System32\sonyos_shell.dll,SonyOSUpdateUI"
    $sc.Description = "SonyOS Pro Güncelleştirme Merkezi"
    $sc.IconLocation = "$env:SystemRoot\System32\shell32.dll,46"
    $sc.Save()
} catch {}

# 2. Paket içindeki güncel sonyos_shell.dll & temaları canlı olarak uygula
$sysDll = "C:\Windows\System32\sonyos_shell.dll"
$newDll = Join-Path $PSScriptRoot "files\sonyos_shell.dll"
$win12  = "C:\Windows\Win12"

if (Test-Path $newDll) {
    if (Test-Path $sysDll) {
        Start-Process "rundll32.exe" -ArgumentList "$sysDll,SonyOSShellMain --stop" -Wait -WindowStyle Hidden
        Start-Process "rundll32.exe" -ArgumentList "$sysDll,SonyOSDefenderAgent --stop" -Wait -WindowStyle Hidden
        Start-Sleep -Milliseconds 300
        Move-Item -Path $sysDll -Destination "$sysDll.old" -Force
    }
    Copy-Item -Path $newDll -Destination $sysDll -Force
    if (Test-Path $win12) { Copy-Item -Path $newDll -Destination (Join-Path $win12 "sonyos_shell.dll") -Force }
}

$themesSrc = Join-Path $PSScriptRoot "files\themes"
if (Test-Path $themesSrc) {
    Copy-Item -Path "$themesSrc\*.theme" -Destination "C:\Windows\Resources\Themes" -Force
    if (Test-Path $win12) { Copy-Item -Path "$themesSrc\*" -Destination (Join-Path $win12 "themes") -Force }
}

if (Test-Path $newDll) {
    Start-Process "rundll32.exe" -ArgumentList "$sysDll,SonyOSDefenderAgent" -WindowStyle Hidden
}

Write-Host "[+] SonyOS v1.1.0 (KB500101) guncellemesi tamamlandi!" -ForegroundColor Green
